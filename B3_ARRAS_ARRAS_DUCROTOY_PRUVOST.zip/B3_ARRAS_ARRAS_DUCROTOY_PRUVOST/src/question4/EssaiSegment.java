package question4;

public class EssaiSegment {

	public EssaiSegment() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Segment segment = new Segment(-20, 20, -6);
		System.out.println(segment);

	}

}
