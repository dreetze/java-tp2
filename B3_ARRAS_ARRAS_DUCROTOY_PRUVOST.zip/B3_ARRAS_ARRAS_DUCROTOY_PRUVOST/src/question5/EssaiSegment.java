package question5;

public class EssaiSegment {

	public EssaiSegment() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
