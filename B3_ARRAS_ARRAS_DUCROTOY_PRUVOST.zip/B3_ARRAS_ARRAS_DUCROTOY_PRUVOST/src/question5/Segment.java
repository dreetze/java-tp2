package question5;

public class Segment {
	
	Point a = new Point(2,4);
	Point b = new Point(3,5);
	
	
	
	public int valeurSegment(){
		return 5;
	}

	public Segment() {
		// TODO Auto-generated constructor stub
	}

}
