package com.epsi.tp1;

public class Scope {

	public Scope() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		int i=0;
		//for(int i=0, i<5, i++){
		for(i=0; i<5; i++){
			//int i;
			System.out.print(i+", ");
		}
		System.out.print("\n");

	}

}
